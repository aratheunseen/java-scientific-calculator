package bd.edu.vu.scientificcalculator;

public class ScientificCalculator {
    public static void main(String[] args) {
        CalculatorUI scientific = new CalculatorUI();
        scientific.setVisible(true);
    }
}